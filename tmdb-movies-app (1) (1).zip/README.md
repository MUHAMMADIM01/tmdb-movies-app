# TMDB Movies App

This is a simple React app to display movie cards.