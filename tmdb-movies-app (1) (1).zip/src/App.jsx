import React from 'react';
import MovieCard from './components/MovieCard';

const App = () => {
  const dummyMovie = { title: 'Sample Movie' };
  return (
    <div>
      <h1>TMDB Movies App</h1>
      <MovieCard movie={dummyMovie} />
    </div>
  );
};

export default App;