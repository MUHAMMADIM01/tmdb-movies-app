# TMDB Movies App

A simple React app using Vite to display movie cards.