import React from 'react';
export default function MovieCard({ movie }) { return <div>{movie.title}</div>; }