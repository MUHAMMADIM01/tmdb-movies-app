import React from 'react';
import MovieCard from './components/MovieCard';
export default function App() { return <div><MovieCard movie={{title: 'Sample Movie'}} /></div>; }